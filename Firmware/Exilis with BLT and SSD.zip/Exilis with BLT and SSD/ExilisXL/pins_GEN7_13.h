/**
 * Gen7 v1.3 pin assignments
 */

#define MOTHERBOARD BOARD_GEN7_12
#define GEN7_VERSION 13 // v1.3

#include "pins_GEN7_12.h"
